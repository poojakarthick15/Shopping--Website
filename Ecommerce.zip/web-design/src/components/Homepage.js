import React from 'react';
import '../Styles/Homepage.css';
import {Link} from 'react-router-dom';
function Homepage(){
    return(
         <div className="homepage-cover">
             <div className="homepage-parallel">
                 <div className="boy">
                     <Link to="/Myboyfrnd" className="girl">
                         <div className="mega-btn">
                             <div className="mega-btn-content">
                                 <h4>Shop My Boyfriends Back</h4>
                             </div>
                         </div>
                     </Link>
                 </div>
             </div>

         </div>
    );
}
export default Homepage;