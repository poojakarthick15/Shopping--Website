import React from 'react';
import Title from './Title';
import Product from './Product';
import {ProductConsumer} from '../context';
import '../Styles/Productlist.css';
class Productlist extends React.Component{
 
  render(){
   
    return(
      <React.Fragment>
           <div className="prolist py-5">
               <div className="container">
                   <Title name="Featured" title="Products"/>
                   <div className="row">
                     
                        <ProductConsumer>
                          {(value)=>{
                            return value.products.map(product=>{
                              return <Product key={product.id} product={product}/>;
                            })

                          }}
                        </ProductConsumer>
                   </div>
                   
              </div>
           </div>
      </React.Fragment>
      
  );
    }
}
export default Productlist;