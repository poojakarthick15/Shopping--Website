import React from 'react';
import '../Styles/Footer.css';
function Footer(){
    return(
        <div className="footer">
        <div className="container">
            <div className="row">
                <div className="col col-lg-4">
                <h4>Customer Care</h4>
                <hr/>
                   <ul className="menu">
                       <li classname="list">contact us</li>
                       <li classname="list">faq</li>
                       <li classname="list">the story</li>
                       <li classname="list">store location</li>
                       <li classname="list">blog</li>
                       <li classname="list">careers</li>
                       <li classname="list">terms of use</li>
                       <li classname="list">shipping</li>
                       <li classname="list">returns</li>
                       <li classname="list">privacy policy</li>
                   </ul>
                </div>
                
                <div className="col col-lg-4">
                <h4>About</h4>
                <hr/>
                    <p><b>Hebe, bebe</b></p>
                    <p>Curators of ethical fashion and New Zealand designed. </p>
                    <p>Hebe is a destination for style seekers. Located in Masterton's boutique Kuripuni Village, Hebe is lovingly and carefully curated by Owner and Buyer, Dani Burkhart. Dedicated to NZ designed, ethical fashion and accessories- Hebe is a beautiful style edit.</p>
                    <p>Spliced on the rack, you will discover a mix of your favourite boutique labels, lounge-wear and lifestyle products. Hebe presents small, regular collections from designers that are limited in nature with a high rotation. For all women, all sizes, Hebe is the go-to fashion boutique of the Wairarapa. Purchases made at Hebe support suppliers and makers within NZ- shop local, shop small!</p>
                    <p>Feel inspired exploring a beautifully designed space that reflects a love for styling and creating. Style tips await from a small, warm team who adore fashion- the current, the classic and the refined.</p>
                    <p>A truly authentic element of the store, Owner Dani Burkhart, produces in-house clothing label My Boyfriends Back from Hebe, for Hebe. Shoppers can order different colours in signature styles, and select from seasonal pieces available instore. MBB is designed using surplus fabric stocks and is made in Auckland, NZ.</p>
                    <div>
                    
                    <i className="fa fa-cc-amex fa-2x"></i>
                    <i className="fa fa-cc-mastercard fa-2x pl-5" aria-hidden="true"></i>
                    <i className="fa fa-cc-paypal fa-2x pl-5" aria-hidden="true"></i>
                    <i className="fa fa-cc-visa fa-2x pl-5" aria-hidden="true"></i>
                    
                    </div>
                    <div className="social-media">
                    <i className="fa fa-facebook-official" aria-hidden="true"></i>
                    <i className="fa fa-instagram pl-5" aria-hidden="true"></i>
                    </div>
                    <p className="text-uppercase">&copy;copyright hebe designer boutique 2020</p>

                    
                </div>
                <div className="col col-lg-4">
                <h4>Newsletter</h4>
                <hr/>
                <p>Join our mailing list</p>
                <div className="container bg-light">
                    <form>
                        <input type="email" name="email" placeholder="your@email.com"/>
                        <button className="subscribe-btn bg-dark">Subscribe</button>
                    </form>
                </div>
                </div>
            </div>
        </div>
        </div>
    );
}
export default Footer;