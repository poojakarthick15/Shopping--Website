import React from 'react';
import '../Styles/Navbar.css';
import {Link} from 'react-router-dom';
function Navbar(){
    return(
        <div className="Wrapper">
            <div className="Navbar1">
            <nav className="navbar navbar-expand-lg navbar-dark">
               <ul className="navbar-nav ml-auto">
                    <li className="nav-item text-uppercase">
                        <Link to="/login" className="nav-link">
                            login
                        </Link>
                    </li>
                    <li className="nav-item  text-uppercase">
                        <Link to="/createaccount" className="nav-link">
                            create account
                        </Link>
                    </li>
                </ul>
            </nav>
            </div>
            <div className="Navbar2">
            <nav className="navbar navbar-expand-lg navbar-light">
                <h1 className="navbar-brand">hebe.</h1>
                     <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                     <span className="navbar-toggler-icon"></span>
                     </button>
                     <div className="collapse navbar-collapse" id="navbarSupportedContent">
               <ul className="navbar-nav ml-auto">
                    
                    <li className="nav-item text-uppercase">
                        <Link to="/" className="nav-link">
                            Home
                        </Link>
                    </li>
                    <li className="nav-item text-uppercase">
                        <Link to="/shop" className="nav-link">
                            shop
                        </Link>
                    </li>
                    <li className="nav-item  text-uppercase">
                        <Link to="/myboyfrnd" className="nav-link">
                            my boyfriend back
                        </Link>
                    </li>
                    <li className="nav-item  text-uppercase">
                        <Link to="/staffedit" className="nav-link">
                            staff edit
                        </Link>
                    </li>
                    <li className="nav-item  text-uppercase">
                        <Link to="/contact" className="nav-link">
                            contact
                        </Link>
                    </li>
                    <li className="nav-item  text-uppercase">
                        <Link to="/cart" className="nav-link">
                            cart
                        </Link>
                    </li>
                </ul>
                </div>
            </nav>
            </div>
        </div>
        

        
        
    );
}
export default Navbar;
