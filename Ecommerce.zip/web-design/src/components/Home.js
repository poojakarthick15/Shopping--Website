import React from 'react';
import '../Styles/Home.css';
import Productlist from '../components/Productlist';
import Homepage from '../components/Homepage';
import Footer from '../components/Footer';
import {Link} from 'react-router-dom';

function Home(){
    return(
        <div className="Home">
        <div className="container-fluid">
             <h1>SABEN New Season</h1>
             <Link className="main-link">Shop now</Link>
        </div>
        <Productlist/>
        <Homepage/>
        <Footer/>
        </div>
        
        
    );
}
export default Home;