import React from 'react';
import CartItem from '../components/CartItem';
function Cartlist({value}){
    
    const {cart}=value;
    console.log(value,cart);
    return(
        <div className="carlist">
            {
                cart.map(item=>{
                    return <CartItem key={item.id} item={item} value={value}/>;
                })
            }
           
        </div>
    );
}
export default Cartlist;