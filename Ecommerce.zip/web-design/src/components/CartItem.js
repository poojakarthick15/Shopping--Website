import React from 'react';
import '../Styles/CartItem.css';
function CartItem({item,value}){
  const{id,title,img,price,total,count}=item;
  const {increment,decrement,removeItem}=value;
  return(
    <div className="row my-2 text-capitalize text-center">
      <div className="col-10 mx-auto col-lg-2">
        <img src={img} alt="product" style={{width:"5rem",height:"5rem"}}/>
      </div>
      <div className="col-10 mx-auto col-lg-2">
       <span className="d-lg-none">Product:</span>
       {title}
      </div>
      <div className="col-10 mx-auto col-lg-2">
       <span className="d-lg-none">Price:</span>
       {price}
      </div>
      <div className="col-10 mx-auto my-2 my-lg-0 col-lg-2">
        <div className="d-flex justify-content-center">
          <div>
            <span><button className="btn-black mx-1"
             onClick={()=>decrement(id)}>
              -
              </button>
            </span>
            <span><button className="btn-black mx-1">{count}</button></span>
            <span><button className="btn-black mx-1"
             onClick={()=>increment(id)}>
              +
              </button>
            </span>
          </div>
          
          
        </div>
      </div>
      <div className="col-10 mx-auto col-lg-2">
        <div className="cart-icon" onClick={()=>removeItem(id)}>
          <i className="fa fa-trash"></i>
        </div>
      
      </div>
      <div className="col-10 mx-auto col-lg-2">
        <strong>item total: &#8377;{total}</strong>
      
      </div>
    </div>
  );

}


export default CartItem;