import React from 'react';
import Footer from '../components/Footer';
function Createaccount(){
    return(
        <div className="container">
            <h2 className="head-login">Create Account</h2>
            <div className="form-in">
            <form className="my-form">
                <div className="my-field pt-3 ">
                <input type="text" name="fname" placeholder="First Name"/>
                </div>
                <div className="my-field pt-3 ">
                <input type="text" name="lname" placeholder="Last Name"/>
                </div>
                <div className="my-field pt-3 ">
                <input type="email" name="email" placeholder="Email"/>
                </div>
                <div className="my-field pt-2">
                <input type="password" name="password" placeholder="Password"/>
                </div>
                <div className="my-field pt-2">
                <button className="sign-btn bg-dark">Create</button>
                </div>
                <div className="sub-menu">
                    <ul className="lists d-flex px-5">
                    <li className="sub">Return to shop</li>
                    <li className="sub pl-4">Log In</li>
                    </ul>
                </div>
            </form>

            
            </div>
            <Footer/>
        </div>
    );
}
export default Createaccount;