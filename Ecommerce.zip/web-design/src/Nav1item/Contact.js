import React from 'react';
import '../Styles/contact.css';
import Footer from '../components/Footer';
function Contact(){
    return(
        <div className="contact">
            <div className="container">
            <h3 className="pt-5">Contact Us</h3>
            <p>If you have a query regarding an element of our website whether it be about processing or an aspect of your order, our in-store team would love to assist you. Don't hesitate to contact us on the following email, or call the store between our working hours. We also channel feedback through our Facebook Page and Instagram. We will aim to reply to your query within 24 working hours. For all product and order enquiries please email: </p>
            <h6><span>hellothere@hebeboutique.com</span></h6>
            <p>To all designers wishing to contact the store with wholesale enquiries, please contact Danielle Burkhart:<span> shop@hebeboutique.com</span> If we feel as though your brand would fit within our portfolio, we will get in touch!</p>
            <p>For all retailers, or media and press wishing to express interest in self-designed label My Boyfriends Back, enquiries can be directed to Danielle Burkhart:<span> theheart@myboyfriendsback.co.nz</span></p>
            <h6>Follow us<span> @hebeboutique xx</span></h6>
<p>Our team at Hebe are always interested in your feedback to do with your physical and online shopping experience and our services. You can forward your comments to the supplied emails or find us on Facebook!</p>
<p>Thank you so much for supporting your local, as well as NZ designers and brands! x

</p>
            </div>
            <Footer/>
            
        </div>
    );
}
export default Contact;