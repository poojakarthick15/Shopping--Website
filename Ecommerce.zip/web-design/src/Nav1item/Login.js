import React from 'react';
import '../Styles/Login.css';
import {Link} from 'react-router-dom';
import Footer from '../components/Footer';
function Login(){
    return(
        <React.Fragment>
            
        <div className="container">
            <h2 className="head-login">Login</h2>
            <div className="form-in">
            <form className="my-form">
                <div className="my-field pt-3 ">
                <input type="email" name="email" placeholder="Email"/>
                </div>
                <div className="my-field pt-2">
                <input type="password" name="password" placeholder="Password"/>
                </div>
                <div className="my-field pt-2">
                <button className="sign-btn bg-dark">Sign In</button>
                </div>
                <div className="sub-menu">
                    <ul className="lists d-flex px-5">
                    <li className="sub">
                        <Link to="/">Return to shop</Link>
                    </li>
                    <li className="sub pl-4">
                        <Link>Forgot your password?
                        </Link>
                        </li>
                    </ul>
                </div>
            </form>

            
            </div>
            <Footer/>
        </div>
        
        </React.Fragment>
    );
}
export default Login;