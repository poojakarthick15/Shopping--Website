import React from 'react';
import '../Styles/Myboyfrnd.css';
import Footer from '../components/Footer';
function Myboyfrnd(){
    return(
        <div>
        <div className="frnd">
            <div className="container">
            <h3 className="pt-5">My Boyfriends Back</h3>
            <p>My Boyfriends Back is Hebe's self designed clothing label, sizing from 6-16. New Zealand designed and made, My Boyfriends Back is nestled in Wellington City’s backyard; the winding, wonderland of the Wairarapa. Juxtaposing the hustle and bustle of the city with the relative calm and fragrant air of the hills, this is beautifully reflected in designer Dani Burkhart’s creations.</p>
            <p>Every season Dani builds her collections around function, comfort and quality – always combining feminine romanticism and a heavier, darker inspiration. Dani is drawn to a feminine, moody aesthetic. Preferring classic styles to have a  touch of drama through drape, texture or tone.</p>
            <p>Since 2010 My Boyfriends Back has blossomed and evolved, taking inspiration from imagery, culture trends and from her different attitude to fashion now that she is a mother. This is reflected in her approach to every aspect of the brand – from the collections, to the marketing.</p>
            <p>Dani Burkhart is proud to be designing and producing her collection in New Zealand – collaborating and working with some of the finest New Zealand based artists, photographers, writers and productions teams to enable her to bring her vision to life. </p>
            </div>
           
        </div>
        <Footer/>
        </div>
    );
}
export default Myboyfrnd;