import React from 'react';
import Title from '../components/Title';
import CartCol from '../components/CartCol';
import Emptycart from '../components/Emptycart';
import {ProductConsumer} from '../context';
import Cartlist from '../components/Cartlist';
import CartTotals from '../components/CartTotals';
function Cart(){
    return(
        <section>
            <ProductConsumer>
                {value=>{
                    const {cart}=value;
                    if(cart.length>0){
                        return (
                            <React.Fragment>
                            <Title name="your" title="cart"/>
                            <CartCol/>
                            <Cartlist value={value}/>
                            <CartTotals value={value}/>
                            </React.Fragment>
                        );
                    }
                    else{
                      return(<Emptycart/>);
                    }
                }}
            </ProductConsumer>
           
            
        </section>
    );
}
export default Cart;