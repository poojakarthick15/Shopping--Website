import React from 'react';
import Footer from '../components/Footer';
function Shop(){
    return(
        <div className="container bg-light">
            <div className="row pb-5">
                <div className="col-lg-3 pt-5 pl-5">
                    <h5>SHOP BY</h5>
                    <ul>
                        <li>Accessories</li>
                        <li>Bottoms</li>
                        <li>Dresses</li>
                        <li>Tops</li>
                        <li>Pre-Order</li>
                        <li>under $50</li>
                        <li>under $100</li>
                        <li>Sold out with suppliers</li>
                        <li>Sale</li>
                        <li>Gift Vouchers</li>
                        <li>View All</li>
                        
                    </ul>
                </div>
                <div className="col-lg-3 pt-5 pl-5">
                <h5>BRANDS</h5>
                    <ul>
                        <li>Betty Basics</li>
                        <li>Cooper St</li>
                        <li>Ketz-ke</li>
                        <li>NYNE</li>
                        <li>Ricochet</li>
                        <li>LEO+BE</li>
                        <li>Lindi kingi Design</li>
                        <li>Flash Jwellery</li>
                        <li>SOPHIE</li>
                        <li>Twenty Seven Names</li>
                        <li>Rejuvenated Collagen</li>
                        <li>Clique Fitness</li>
                        <li>Good And Co Scarves</li>
                        
                    </ul>
                </div>
                <div className="col-lg-3 pt-5 pl-5">
                    <ul>
                    
                        <li>commoners Alike</li>
                        <li>FATE</li>
                        <li>LTB Denim</li>
                        <li>Once Was</li>
                        <li>ROSEFIELD</li>
                        <li>Blak</li>
                        <li>Koko Body</li>
                        <li>Remain</li>
                        <li>Saben</li>
                        <li>Stolen Girlfriends Club</li>
                        <li>Cartel and Willows</li>
                        <li>Prene Bags</li>
                        <li>Carly Paiker Jewellery</li> 
                    </ul>
                </div>
                <div className="col-lg-3 pt-5 pl-5">
                    <ul>
                   
                        <li>COOP</li>
                        <li>Gorge and Edi</li>
                        <li>My Boyfriend Back</li>
                        <li>QUAY  Eyewear</li>
                        <li>Tuesday</li>
                        <li>Staple+Cloth</li>
                        <li>Marle</li>
                        <li>Karen Walker Fragrances</li>
                        <li>FoxWood</li>
                        <li>Assembly Label</li>
                        <li>Ziggy Denim</li>
                        <li>Rue Stiic</li> 
                    </ul>
                </div>
            </div>
            <Footer/>
        </div>
    );
}
export default Shop;