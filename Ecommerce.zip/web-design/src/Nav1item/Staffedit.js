import React from 'react';
import '../Styles/Staffedit.css';
import Footer from '../components/Footer';
function Staffedit(){
    return(
        <div>
        <div className="staffedit">

                
                <h3>Staff Edit</h3>
                <p>Hebe Designer Boutique reflects a strong sense of style and individual tastes, showcasing in a curated space carefully selected brands. Hebe believes that garments should be worn and loved. The ability to transform ones ensemble from day-wear to luxe is available to everyone with a library of labels and aesthetics to choose from in-store. Obsessed with fashion and blurring the lines between clear trends, the staff at Hebe admire looks of all origin and enjoy mashing up outfits, layering and indulging in looks varying from classic to contemporary, feminine and androgynous. Follow our staff edit as we select products from in-store that inspire us towards a new outfit or the addition of effortless essentials. Hebe has a high stock rotation with new garments arriving weekly and loves to support NZ designed.</p>
            
        </div>
        <Footer/>
        </div>
    );
}
export default Staffedit;