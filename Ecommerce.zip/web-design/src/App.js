import React from 'react';
import Navbar from './components/Navbar';
import './App.css';
import {BrowserRouter as Router,Switch,Route} from 'react-router-dom';
import Login from './Nav1item/Login';
import Createaccount from './Nav1item/Createaccount';
import Cart from './Nav1item/Cart';
import Contact from './Nav1item/Contact';
import Myboyfrnd from './Nav1item/Myboyfrnd';
import Shop from './Nav1item/Shop';
import Staffedit from './Nav1item/Staffedit';
import details from './components/details';
import Home from './components/Home';
import 'bootstrap/dist/css/bootstrap.min.css';
function App() {
  return (
    <React.Fragment>
      <Router>
       <Navbar/>
       <Switch>
          <Route path="/login" component={Login}/>
          <Route path="/createaccount" component={Createaccount}/>
          <Route path="/shop" component={Shop}/>
          <Route path="/myboyfrnd" component={Myboyfrnd}/>
          <Route path="/staffedit" component={Staffedit}/>
          <Route path="/contact" component={Contact}/>
          <Route path="/cart" component={Cart}/>
          <Route path="/details" component={details}/>
          <Route path="/" component={Home}/>
       </Switch>
       </Router>
       
       
  </React.Fragment>
   
  );
}

export default App;
