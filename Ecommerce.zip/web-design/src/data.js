export const storeProducts = [
    {
        id:1,
        title:"Adaline Shirt Dress",
        info:"The Adaline Shirt Dress is the perfect addition to any wardrobe. Handmade and dyed, this stunningly soft piece is the dress you never knew you needed!Dress this versatile piece up with heels or down with flats for a chic look. Easy wearing the Adaline Shirt Dress is perfect all year round. Featuring a relaxed fit, button up front and elasticated wrists, the Adaline Shirt Dress won't disappoint.Made in a luxe Rayon, this stunning dress is both soft and breathable. Perfect for layering or a more relaxed coastal look.This stunning Dress is also a favourite for expecting Mums, with its loose fit and button up front.",
        img:"https://cdn.shopify.com/s/files/1/1132/3440/products/71ED4DD2-ABFC-4B74-B93E-6924674361D4_large.jpg?v=1605049516",
        price:209.00,
        incart:false,
        total:0
    },
    {
        id:2,
        title:"Anya Ribbed Tee//Powder Blue",
        info:"A staple in every wardrobe the Anya Rib Tee will soon become apart of your everyday essentials. A relaxed fit with scoop neckline and cropped sleeve you’ll need one in every colour. Perfect with your favourite denim for an effortless everyday look. ",
        img:"https://cdn.shopify.com/s/files/1/1132/3440/products/78F91455-B68A-4FFD-8021-84C4D8B8145A_large.jpg?v=1600233094",
        price:229.00,
        incart:false,
        total:0
    },
    {
        id:3,
        title:"Bombshell Slip//Black With White Spot",
        info:"A classic bias cut slip dress, adjustable thin straps, with hidden detail stitching across the dress that adds a flare to the hem.",
        img:"https://cdn.shopify.com/s/files/1/1132/3440/products/8E1D0D2D-32A2-4376-B9AC-BB0544E98BBE_large.jpg?v=1599092369",
        price:179.00,
        incart:false,
        total:0
    },
    {
        id:4,
        title:"Chain Feature Handle",
        info:"Transform any bag with our new light gold feature handle. Imagine her dressing up bags being worn draped across their front or used as a small handle to add some fun to clutches.*The chain feature handle is best used draped across Matilda, Big Sis Tilly, Jaxon, Odile, or use the feature handle as a mini handle strap or wrislet on your Tilly Cross-body or Frilly Tilly.",
        img:"https://cdn.shopify.com/s/files/1/1132/3440/products/image_672d5d57-2c78-4ad0-a9d3-9ba269a94d83_large.jpg?v=1607306162",
        price:60.00,
        incart:false,
        total:0
    },
    {
        id:5,
        title:"Chantily Dress",
        info:"A maxi dress, with tiered body, button up front and adjustable straps.",
        img:"https://cdn.shopify.com/s/files/1/1132/3440/products/3C3FCF11-ADDD-4675-AA63-B1B4025D5B0D_large.png?v=1602040563",
        price:479.00,
        incart:false,
        total:0
    },
    {
        id:6,
        title:"Dreamer Tee//Black",
        info:"Our cutest sheer signature, everyone falls in love with the The Dreamer Tee. An update to your tee selection, the Dreamer Tee is a cropped style made from buttery soft chiffon, available in a variety of neutral tones to lift your styling game. Relaxed yet shaped, this style includes bust darts and is true to size. Cute tie detail at the sleeves falls from a petal like crown and enables you to finish your to your mood.",
        img:"https://cdn.shopify.com/s/files/1/1132/3440/products/25F97898-E2EB-4C7E-81AF-44F97EFBA74C_large.jpg?v=1600660834",
        price:279.00,
        incart:false,
        total:0
    },
    {
        id:7,
        title:"Envious Dress",
        info:"Our cutest sheer signature, everyone falls in love with the The Dreamer Tee. An update to your tee selection, the Dreamer Tee is a cropped style made from buttery soft chiffon, available in a variety of neutral tones to lift your styling game. Relaxed yet shaped, this style includes bust darts and is true to size. Cute tie detail at the sleeves falls from a petal like crown and enables you to finish your to your mood.",
        img:"https://cdn.shopify.com/s/files/1/1132/3440/products/image_51447a71-603f-4f4b-aebb-3d1a09281c65_large.jpg?v=1587793636",
        price:546.00,
        incart:false,
        total:0
    },
    {
        id:8,
        title:"Fleur Maxi",
        info:"Our cutest sheer signature, everyone falls in love with the The Dreamer Tee. An update to your tee selection, the Dreamer Tee is a cropped style made from buttery soft chiffon, available in a variety of neutral tones to lift your styling game. Relaxed yet shaped, this style includes bust darts and is true to size. Cute tie detail at the sleeves falls from a petal like crown and enables you to finish your to your mood.",
        img:"https://cdn.shopify.com/s/files/1/1132/3440/products/3C3FCF11-ADDD-4675-AA63-B1B4025D5B0D_large.png?v=1602040563",
        price:846.00,
        incart:false,
        total:0
    },
    {
        id:9,
        title:"Leather Jacket Keyring",
        info:"Our cutest sheer signature, everyone falls in love with the The Dreamer Tee. An update to your tee selection, the Dreamer Tee is a cropped style made from buttery soft chiffon, available in a variety of neutral tones to lift your styling game. Relaxed yet shaped, this style includes bust darts and is true to size. Cute tie detail at the sleeves falls from a petal like crown and enables you to finish your to your mood.",
        img:"https://cdn.shopify.com/s/files/1/1132/3440/products/25F97898-E2EB-4C7E-81AF-44F97EFBA74C_large.jpg?v=1600660834",
        price:746.00,
        incart:false,
        total:0
    }

];
export const detailProduct={
    id:1,
    title:"Adaline Shirt Dress",
    company:"RUE STIIC",
    info:"The Adaline Shirt Dress is the perfect addition to any wardrobe. Handmade and dyed, this stunningly soft piece is the dress you never knew you needed!Dress this versatile piece up with heels or down with flats for a chic look. Easy wearing the Adaline Shirt Dress is perfect all year round. Featuring a relaxed fit, button up front and elasticated wrists, the Adaline Shirt Dress won't disappoint.Made in a luxe Rayon, this stunning dress is both soft and breathable. Perfect for layering or a more relaxed coastal look.This stunning Dress is also a favourite for expecting Mums, with its loose fit and button up front.",
    img:"https://cdn.shopify.com/s/files/1/1132/3440/products/71ED4DD2-ABFC-4B74-B93E-6924674361D4_large.jpg?v=1605049516",
    price:209.00,
    incart:false,
    total:0
};
    